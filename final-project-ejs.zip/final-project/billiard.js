const express = require("express");
const { MongoClient } = require("mongodb");

const app = express();
const port = 4500;

const uri = "mongodb://localhost:27017/fergus";
const options = {
    useNewUrlParser: true,
    useUnifiedTopology: true,
  };
  
  app.use(express.static('public'));
  app.set('view engine', 'ejs');
  app.set('views, __dirname + ./views');


  app.get('/', async(req,res) => {
    try{

    const client = await MongoClient.connect(uri, options);
    const db = client.db();
    const collection = db.collection('collection1');

    const data = await collection.find({}).toArray();
    res.render('index', {data});

    client.close();
    }
    catch(err){
        console.error('Error fetching data from MongoDB:', err);
        res.status(500).send('Internal Server Error');
    }

  });

  app.get('/loginPage', (req,res) =>{
    res.render('loginPage')
  });

  app.get('/cart', (req,res) =>{
    res.render('cart')
  });



  app.listen(port, () => {
    console.log(`Server is running on http://localhost:${port}`);
  });



